# Fighting-Game-Kaboomjs
Fighting game made with the Kaboom.js library for a YouTube tutorial 

[JavaScript Fighting Game Tutorial Made Simpler w/ Kaboom.js](https://www.youtube.com/watch?v=TLH0taCeE6I)

Original assets used in this tutorial

Oak Woods Assets: https://brullov.itch.io/oak-woods

Fighter Asset #1: https://luizmelo.itch.io/martial-hero

Fighter Asset #2: https://luizmelo.itch.io/martial-hero-2

Link for demo: https://jslegend.itch.io/fighting-game-tutorial-kaboomjs
